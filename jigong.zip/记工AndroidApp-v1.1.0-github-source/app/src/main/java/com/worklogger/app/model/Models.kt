package com.worklogger.app.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 同步状态枚举
 */
enum class SyncStatus(val value: Int) {
    SYNCED(0),           // 已同步
    PENDING(1),          // 待同步
    FAILED(2);           // 同步失败
    
    companion object {
        fun fromValue(value: Int): SyncStatus = entries.find { it.value == value } ?: PENDING
    }
}

/**
 * 记工记录实体
 */
@Entity(tableName = "work_records")
data class WorkRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val date: String,           // yyyy-MM-dd
    val hours: Double,          // 工时
    val isOvertime: Boolean,    // 是否加班
    val location: String,       // 工作地点
    val remark: String,         // 备注
    val mealSubsidy: Boolean,   // 是否有饭补
    val isManual: Boolean,      // 是否手动折算
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
    // 同步相关字段
    val syncStatus: Int = SyncStatus.PENDING.value,  // 0-已同步 1-待同步 2-同步失败
    val lastSyncAt: Long = 0,                        // 最后同步时间戳
    val serverId: Int? = null                        // 服务器记录ID，用于双向同步
)

/**
 * 快捷短语实体
 */
@Entity(tableName = "quick_phrases")
data class QuickPhrase(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val phrase: String,
    val useCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * 用户设置数据类
 */
data class UserSettings(
    val dailyWorkHours: Double = 8.0,      // 每日标准工时
    val overtimeRate: Double = 1.0,        // 加班折算比例
    val dailyWage: Double = 0.0,           // 日工资标准
    val monthTarget: Double = 22.0,        // 月工时目标（标准工天数）
    val mealSubsidyStandard: Double = 0.0, // 饭补标准（元/天）
    val offWorkTime: String = "18:00",     // 下班时间 HH:mm
    val offWorkReminder: Boolean = true,   // 下班提醒开关
    val missedDayReminder: Boolean = true, // 漏记提醒开关
    val theme: String = "system",         // system/light/dark
    val biometricEnabled: Boolean = false  // 生物识别开关
)

/**
 * 同步设置数据类
 */
data class SyncSettings(
    val syncEnabled: Boolean = false,      // 云同步开关
    val serverUrl: String = "http://localhost:8080",  // 服务器地址
    val authToken: String = "",            // 认证Token
    val userId: Int = 0,                   // 用户ID
    val username: String = "",              // 用户名
    val lastSyncTime: Long = 0,            // 最后同步时间
    val mobileSyncEnabled: Boolean = false, // 移动网络同步开关
    val pendingCount: Int = 0             // 待同步数量
)

/**
 * 统计数据类
 */
data class StatsData(
    val standardDays: Double = 0.0,       // 标准工天数
    val manualDays: Double = 0.0,          // 手动折算天数
    val overtimeHours: Double = 0.0,      // 加班总小时
    val overtimeDays: Double = 0.0,        // 加班折算天数
    val totalStandard: Double = 0.0,       // 总标准工
    val mealSubsidyTotal: Double = 0.0,    // 饭补合计
    val wageTotal: Double = 0.0,          // 应发工资
    val dailyWage: Double = 0.0           // 日工资标准
)

/**
 * 月份统计数据
 */
data class MonthlyStats(
    val year: Int,
    val month: Int,
    val stats: StatsData,
    val recordCount: Int,
    val overtimeDistribution: Map<Double, Int> // 加班天数分布
)

/**
 * 记录类型枚举
 */
enum class RecordType {
    STANDARD,    // 标准工
    OVERTIME,    // 加班
    MANUAL       // 手动折算
}

/**
 * 记录颜色类型
 */
enum class RecordColorType {
    STANDARD,    // 蓝色
    OVERTIME,    // 橙色
    MANUAL,      // 青色
    DELETED      // 灰色
}

/**
 * 同步日志条目
 */
data class SyncLogEntry(
    val timestamp: Long = System.currentTimeMillis(),
    val type: SyncLogType,
    val message: String,
    val success: Boolean
)

enum class SyncLogType {
    UPLOAD,      // 上传
    DOWNLOAD,    // 下载
    LOGIN,       // 登录
    MANUAL,      // 手动同步
    AUTO         // 自动同步
}
