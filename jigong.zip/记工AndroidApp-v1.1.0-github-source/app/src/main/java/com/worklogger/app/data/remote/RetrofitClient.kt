package com.worklogger.app.data.remote

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Retrofit客户端单例
 */
object RetrofitClient {
    
    private const val DEFAULT_BASE_URL = "http://localhost:8080/"
    private const val CONNECT_TIMEOUT = 15L
    private const val READ_TIMEOUT = 30L
    private const val WRITE_TIMEOUT = 30L
    
    @Volatile
    private var instance: Retrofit? = null
    
    @Volatile
    private var currentBaseUrl: String = DEFAULT_BASE_URL
    
    @Volatile
    private var authToken: String? = null
    
    /**
     * 更新服务器地址
     */
    fun updateBaseUrl(baseUrl: String) {
        if (baseUrl != currentBaseUrl) {
            currentBaseUrl = baseUrl.ensureTrailingSlash()
            instance = null // 强制重新创建
        }
    }
    
    /**
     * 更新认证Token
     */
    fun updateToken(token: String?) {
        authToken = token
    }
    
    /**
     * 获取API服务实例
     */
    fun getService(): WorkApiService {
        return getRetrofit().create(WorkApiService::class.java)
    }
    
    private fun getRetrofit(): Retrofit {
        return instance ?: synchronized(this) {
            instance ?: buildRetrofit().also { instance = it }
        }
    }
    
    private fun buildRetrofit(): Retrofit {
        val okHttpClient = buildOkHttpClient()
        
        return Retrofit.Builder()
            .baseUrl(currentBaseUrl)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
    
    private fun buildOkHttpClient(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(CONNECT_TIMEOUT, TimeUnit.SECONDS)
            .readTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
            .writeTimeout(WRITE_TIMEOUT, TimeUnit.SECONDS)
        
        // 添加日志拦截器（调试时启用）
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        builder.addInterceptor(loggingInterceptor)
        
        // 添加认证拦截器
        builder.addInterceptor(AuthInterceptor())
        
        return builder.build()
    }
    
    /**
     * 认证拦截器，自动添加Token到请求头
     */
    private class AuthInterceptor : Interceptor {
        override fun intercept(chain: Interceptor.Chain): okhttp3.Response {
            val originalRequest = chain.request()
            
            val token = authToken
            if (token.isNullOrEmpty()) {
                return chain.proceed(originalRequest)
            }
            
            val authenticatedRequest = originalRequest.newBuilder()
                .header("Authorization", "Bearer $token")
                .header("Content-Type", "application/json")
                .build()
            
            return chain.proceed(authenticatedRequest)
        }
    }
    
    /**
     * 确保URL以斜杠结尾
     */
    private fun String.ensureTrailingSlash(): String {
        return if (endsWith("/")) this else "$this/"
    }
}
