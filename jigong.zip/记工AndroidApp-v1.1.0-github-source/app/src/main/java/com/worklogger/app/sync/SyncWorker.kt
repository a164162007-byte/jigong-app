package com.worklogger.app.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.worklogger.app.data.local.AppDatabase
import com.worklogger.app.data.local.SyncSettingsDataStore
import com.worklogger.app.data.remote.NetworkError
import com.worklogger.app.data.remote.RetrofitClient
import com.worklogger.app.data.remote.ServerWorkRecord
import com.worklogger.app.model.SyncLogEntry
import com.worklogger.app.model.SyncLogType
import com.worklogger.app.model.SyncSettings
import com.worklogger.app.model.SyncStatus
import com.worklogger.app.model.WorkRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * 同步工作器
 */
class SyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    
    private val database = AppDatabase.getInstance(context)
    private val syncSettingsDataStore = SyncSettingsDataStore(context)
    
    private val syncManager by lazy { SyncManager(context) }
    
    override suspend fun doWork(): Result {
        return withContext(Dispatchers.IO) {
            try {
                // 1. 检查同步开关
                val settings = syncSettingsDataStore.syncSettings.first()
                if (!settings.syncEnabled) {
                    return@withContext Result.success()
                }
                
                // 2. 检查认证状态
                if (settings.authToken.isEmpty()) {
                    return@withContext Result.failure()
                }
                
                // 3. 更新Retrofit配置
                RetrofitClient.updateBaseUrl(settings.serverUrl)
                RetrofitClient.updateToken(settings.authToken)
                
                // 4. 获取待同步的记录
                val pendingRecords = getPendingRecords()
                
                // 5. 执行同步
                val syncResult = performSync(pendingRecords, settings)
                
                // 6. 更新最后同步时间
                val now = System.currentTimeMillis()
                syncSettingsDataStore.updateLastSyncTime(now)
                
                // 7. 添加同步日志
                val logType = if (runAttemptCount > 0) SyncLogType.AUTO else SyncLogType.MANUAL
                syncSettingsDataStore.addSyncLog(
                    SyncLogEntry(
                        type = logType,
                        message = "同步完成: 上传${syncResult.uploaded}条, 下载${syncResult.downloaded}条",
                        success = true
                    )
                )
                
                Result.success()
            } catch (e: Exception) {
                // 处理不同类型的错误
                val retryable = when (e) {
                    is SocketTimeoutException,
                    is UnknownHostException,
                    is NetworkError.Timeout,
                    is NetworkError.NoNetwork -> true
                    is HttpException -> e.code() in 500..599
                    else -> false
                }
                
                // 添加错误日志
                syncSettingsDataStore.addSyncLog(
                    SyncLogEntry(
                        type = SyncLogType.AUTO,
                        message = "同步失败: ${e.message}",
                        success = false
                    )
                )
                
                if (retryable && runAttemptCount < 3) {
                    Result.retry()
                } else {
                    Result.failure()
                }
            }
        }
    }
    
    /**
     * 获取待同步的记录
     */
    private suspend fun getPendingRecords(): List<WorkRecord> {
        return database.workRecordDao().getAllRecordsSync()
            .filter { it.syncStatus != SyncStatus.SYNCED.value }
    }
    
    /**
     * 执行同步
     */
    private suspend fun performSync(
        pendingRecords: List<WorkRecord>,
        settings: SyncSettings
    ): SyncResult {
        var uploaded = 0
        var downloaded = 0
        
        try {
            // 1. 将本地记录转换为服务器格式
            val serverRecords = pendingRecords.map { it.toServerWorkRecord() }
            
            // 2. 调用批量同步API
            val request = com.worklogger.app.data.remote.BatchSyncRequest(
                records = serverRecords,
                lastSync = settings.lastSyncTime
            )
            
            val response = RetrofitClient.getService().batchSync(request)
            
            if (response.isSuccessful && response.body()?.success == true) {
                val syncResponse = response.body()!!
                
                // 3. 处理服务器返回的记录
                syncResponse.serverRecords?.forEach { serverRecord ->
                    val existingRecord = database.workRecordDao().getAllRecordsSync()
                        .find { it.serverId == serverRecord.id }
                    
                    if (existingRecord != null) {
                        // 更新现有记录（如果服务器版本更新）
                        if (serverRecord.updatedAt > existingRecord.updatedAt) {
                            val updated = existingRecord.fromServerWorkRecord(serverRecord)
                            database.workRecordDao().update(updated)
                            downloaded++
                        }
                    } else {
                        // 添加新记录
                        val newRecord = WorkRecord(
                            date = serverRecord.date,
                            hours = serverRecord.hours,
                            isOvertime = serverRecord.isOvertime,
                            location = serverRecord.location,
                            remark = serverRecord.remark,
                            mealSubsidy = serverRecord.mealSubsidy,
                            isManual = serverRecord.isManual,
                            createdAt = serverRecord.createdAt,
                            updatedAt = serverRecord.updatedAt,
                            isDeleted = serverRecord.isDeleted,
                            deletedAt = serverRecord.deletedAt,
                            syncStatus = SyncStatus.SYNCED.value,
                            lastSyncAt = System.currentTimeMillis(),
                            serverId = serverRecord.id
                        )
                        database.workRecordDao().insert(newRecord)
                        downloaded++
                    }
                }
                
                // 4. 更新本地记录的同步状态
                pendingRecords.forEach { record ->
                    if (!record.isDeleted) {
                        val updated = record.copy(
                            syncStatus = SyncStatus.SYNCED.value,
                            lastSyncAt = System.currentTimeMillis()
                        )
                        database.workRecordDao().update(updated)
                        uploaded++
                    } else {
                        // 删除的记录也需要标记为已同步
                        if (record.serverId != null) {
                            try {
                                RetrofitClient.getService().deleteRecord(record.serverId!!)
                            } catch (e: Exception) {
                                // 忽略删除API错误
                            }
                        }
                        val updated = record.copy(
                            syncStatus = SyncStatus.SYNCED.value,
                            lastSyncAt = System.currentTimeMillis()
                        )
                        database.workRecordDao().update(updated)
                        uploaded++
                    }
                }
            }
        } catch (e: Exception) {
            // 部分失败时更新失败的记录状态
            pendingRecords.forEach { record ->
                val updated = record.copy(syncStatus = SyncStatus.FAILED.value)
                database.workRecordDao().update(updated)
            }
            throw e
        }
        
        return SyncResult(uploaded = uploaded, downloaded = downloaded)
    }
    
    /**
     * 将本地记录转换为服务器格式
     */
    private fun WorkRecord.toServerWorkRecord(): ServerWorkRecord {
        return ServerWorkRecord(
            id = serverId,
            date = date,
            hours = hours,
            isOvertime = isOvertime,
            location = location,
            remark = remark,
            mealSubsidy = mealSubsidy,
            isManual = isManual,
            createdAt = createdAt,
            updatedAt = updatedAt,
            isDeleted = isDeleted,
            deletedAt = deletedAt
        )
    }
    
    /**
     * 从服务器记录创建本地记录
     */
    private fun WorkRecord.fromServerWorkRecord(serverRecord: ServerWorkRecord): WorkRecord {
        return copy(
            date = serverRecord.date,
            hours = serverRecord.hours,
            isOvertime = serverRecord.isOvertime,
            location = serverRecord.location,
            remark = serverRecord.remark,
            mealSubsidy = serverRecord.mealSubsidy,
            isManual = serverRecord.isManual,
            createdAt = serverRecord.createdAt,
            updatedAt = serverRecord.updatedAt,
            isDeleted = serverRecord.isDeleted,
            deletedAt = serverRecord.deletedAt,
            syncStatus = SyncStatus.SYNCED.value,
            lastSyncAt = System.currentTimeMillis(),
            serverId = serverRecord.id
        )
    }
}

/**
 * 同步结果
 */
data class SyncResult(
    val uploaded: Int = 0,
    val downloaded: Int = 0
)
