package com.worklogger.app.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.worklogger.app.data.remote.LoginResponse
import com.worklogger.app.model.SyncLogEntry
import com.worklogger.app.model.SyncSettings
import com.worklogger.app.sync.SyncManager
import com.worklogger.app.sync.SyncState
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * 同步设置UI状态
 */
data class SyncSettingsUiState(
    val syncSettings: SyncSettings = SyncSettings(),
    val syncState: SyncState = SyncState.Idle,
    val syncLogs: List<SyncLogEntry> = emptyList(),
    val isLoggingIn: Boolean = false,
    val showLoginDialog: Boolean = false,
    val showServerUrlDialog: Boolean = false,
    val errorMessage: String? = null,
    val isSyncing: Boolean = false
)

/**
 * 同步设置ViewModel
 */
class SyncSettingsViewModel(
    application: Application
) : AndroidViewModel(application) {
    
    private val syncManager = SyncManager(application)
    
    private val _uiState = MutableStateFlow(SyncSettingsUiState())
    val uiState: StateFlow<SyncSettingsUiState> = _uiState.asStateFlow()
    
    init {
        // 收集同步设置
        viewModelScope.launch {
            syncManager.syncSettings.collect { settings ->
                _uiState.update { it.copy(syncSettings = settings) }
            }
        }
        
        // 收集同步状态
        viewModelScope.launch {
            syncManager.syncStateFlow.collect { state ->
                _uiState.update { it.copy(syncState = state, isSyncing = state == SyncState.Syncing) }
            }
        }
        
        // 收集同步日志
        viewModelScope.launch {
            syncManager.syncLogs.collect { logs ->
                _uiState.update { it.copy(syncLogs = logs) }
            }
        }
    }
    
    /**
     * 切换云同步开关
     */
    fun toggleSyncEnabled(enabled: Boolean) {
        viewModelScope.launch {
            syncManager.updateSyncEnabled(enabled)
            if (!enabled) {
                // 关闭同步时需要先登录
                _uiState.update { it.copy(showLoginDialog = false) }
            }
        }
    }
    
    /**
     * 打开登录对话框
     */
    fun showLoginDialog() {
        _uiState.update { it.copy(showLoginDialog = true, errorMessage = null) }
    }
    
    /**
     * 关闭登录对话框
     */
    fun hideLoginDialog() {
        _uiState.update { it.copy(showLoginDialog = false, errorMessage = null) }
    }
    
    /**
     * 登录
     */
    fun login(username: String, password: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoggingIn = true, errorMessage = null) }
            
            val result = syncManager.login(username, password)
            
            result.fold(
                onSuccess = {
                    _uiState.update { it.copy(isLoggingIn = false, showLoginDialog = false) }
                },
                onFailure = { e ->
                    _uiState.update { it.copy(isLoggingIn = false, errorMessage = e.message) }
                }
            )
        }
    }
    
    /**
     * 登出
     */
    fun logout() {
        viewModelScope.launch {
            syncManager.logout()
            _uiState.update { it.copy(syncSettings = it.syncSettings.copy(
                authToken = "",
                userId = 0,
                username = ""
            )) }
        }
    }
    
    /**
     * 打开服务器地址对话框
     */
    fun showServerUrlDialog() {
        _uiState.update { it.copy(showServerUrlDialog = true) }
    }
    
    /**
     * 关闭服务器地址对话框
     */
    fun hideServerUrlDialog() {
        _uiState.update { it.copy(showServerUrlDialog = false) }
    }
    
    /**
     * 更新服务器地址
     */
    fun updateServerUrl(url: String) {
        viewModelScope.launch {
            syncManager.updateServerUrl(url)
            _uiState.update { it.copy(showServerUrlDialog = false) }
        }
    }
    
    /**
     * 切换移动网络同步开关
     */
    fun toggleMobileSync(enabled: Boolean) {
        viewModelScope.launch {
            syncManager.updateMobileSyncEnabled(enabled)
        }
    }
    
    /**
     * 手动触发同步
     */
    fun triggerManualSync() {
        if (syncManager.isSyncing()) return
        
        viewModelScope.launch {
            syncManager.updateSyncState(SyncState.Syncing)
            syncManager.triggerManualSync()
        }
    }
    
    /**
     * 清除错误消息
     */
    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }
}

/**
 * SyncSettingsViewModel工厂
 */
class SyncSettingsViewModelFactory(
    private val application: Application
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SyncSettingsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SyncSettingsViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
