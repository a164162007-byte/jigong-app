package com.worklogger.app.data.remote

import com.google.gson.annotations.SerializedName

/**
 * 登录请求
 */
data class LoginRequest(
    val username: String,
    val password: String
)

/**
 * 注册请求
 */
data class RegisterRequest(
    val username: String,
    val password: String
)

/**
 * 登录响应
 */
data class LoginResponse(
    val success: Boolean,
    val message: String? = null,
    val token: String? = null,
    val userId: Int? = null,
    val username: String? = null
)

/**
 * 基础响应
 */
data class BaseResponse(
    val success: Boolean,
    val message: String? = null
)

/**
 * 服务器端记工记录
 */
data class ServerWorkRecord(
    val id: Int? = null,
    val date: String,
    val hours: Double,
    @SerializedName("is_overtime")
    val isOvertime: Boolean,
    val location: String,
    val remark: String,
    @SerializedName("meal_subsidy")
    val mealSubsidy: Boolean,
    @SerializedName("is_manual")
    val isManual: Boolean,
    @SerializedName("created_at")
    val createdAt: Long,
    @SerializedName("updated_at")
    val updatedAt: Long,
    @SerializedName("is_deleted")
    val isDeleted: Boolean,
    @SerializedName("deleted_at")
    val deletedAt: Long? = null
)

/**
 * 记录列表响应
 */
data class RecordsResponse(
    val success: Boolean,
    val records: List<ServerWorkRecord>? = null,
    val message: String? = null
)

/**
 * 批量同步请求
 */
data class BatchSyncRequest(
    val records: List<ServerWorkRecord>,
    @SerializedName("last_sync")
    val lastSync: Long = 0
)

/**
 * 批量同步响应
 */
data class BatchSyncResponse(
    val success: Boolean,
    val uploaded: Int = 0,
    val downloaded: Int = 0,
    @SerializedName("server_records")
    val serverRecords: List<ServerWorkRecord>? = null,
    val message: String? = null
)

/**
 * 网络错误类型
 */
sealed class NetworkError(message: String) : Exception(message) {
    object NoNetwork : NetworkError("无网络连接")
    object Timeout : NetworkError("连接超时")
    object Unauthorized : NetworkError("认证失败，请重新登录")
    object ServerError : NetworkError("服务器错误")
    data class Unknown(val message: String) : NetworkError(message)
}
