package com.worklogger.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.worklogger.app.model.SyncLogEntry
import com.worklogger.app.model.SyncSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.syncDataStore: DataStore<Preferences> by preferencesDataStore(name = "sync_settings")

/**
 * 同步设置数据存储
 */
class SyncSettingsDataStore(private val context: Context) {
    
    private val gson = Gson()
    
    companion object {
        private val SYNC_ENABLED = booleanPreferencesKey("sync_enabled")
        private val SERVER_URL = stringPreferencesKey("server_url")
        private val AUTH_TOKEN = stringPreferencesKey("auth_token")
        private val USER_ID = intPreferencesKey("user_id")
        private val USERNAME = stringPreferencesKey("username")
        private val LAST_SYNC_TIME = longPreferencesKey("last_sync_time")
        private val MOBILE_SYNC_ENABLED = booleanPreferencesKey("mobile_sync_enabled")
        private val SYNC_LOGS = stringPreferencesKey("sync_logs")
        
        private const val MAX_LOG_ENTRIES = 10
    }
    
    val syncSettings: Flow<SyncSettings> = context.syncDataStore.data.map { preferences ->
        SyncSettings(
            syncEnabled = preferences[SYNC_ENABLED] ?: false,
            serverUrl = preferences[SERVER_URL] ?: "http://localhost:8080",
            authToken = preferences[AUTH_TOKEN] ?: "",
            userId = preferences[USER_ID] ?: 0,
            username = preferences[USERNAME] ?: "",
            lastSyncTime = preferences[LAST_SYNC_TIME] ?: 0L,
            mobileSyncEnabled = preferences[MOBILE_SYNC_ENABLED] ?: false
        )
    }
    
    val syncLogs: Flow<List<SyncLogEntry>> = context.syncDataStore.data.map { preferences ->
        val json = preferences[SYNC_LOGS] ?: "[]"
        try {
            val type = object : TypeToken<List<SyncLogEntry>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    suspend fun updateSyncEnabled(enabled: Boolean) {
        context.syncDataStore.edit { preferences ->
            preferences[SYNC_ENABLED] = enabled
        }
    }
    
    suspend fun updateServerUrl(url: String) {
        context.syncDataStore.edit { preferences ->
            preferences[SERVER_URL] = url
        }
    }
    
    suspend fun updateAuthToken(token: String) {
        context.syncDataStore.edit { preferences ->
            preferences[AUTH_TOKEN] = token
        }
    }
    
    suspend fun updateUserId(userId: Int) {
        context.syncDataStore.edit { preferences ->
            preferences[USER_ID] = userId
        }
    }
    
    suspend fun updateUsername(username: String) {
        context.syncDataStore.edit { preferences ->
            preferences[USERNAME] = username
        }
    }
    
    suspend fun updateLastSyncTime(time: Long) {
        context.syncDataStore.edit { preferences ->
            preferences[LAST_SYNC_TIME] = time
        }
    }
    
    suspend fun updateMobileSyncEnabled(enabled: Boolean) {
        context.syncDataStore.edit { preferences ->
            preferences[MOBILE_SYNC_ENABLED] = enabled
        }
    }
    
    suspend fun updateSyncSettings(settings: SyncSettings) {
        context.syncDataStore.edit { preferences ->
            preferences[SYNC_ENABLED] = settings.syncEnabled
            preferences[SERVER_URL] = settings.serverUrl
            preferences[AUTH_TOKEN] = settings.authToken
            preferences[USER_ID] = settings.userId
            preferences[USERNAME] = settings.username
            preferences[LAST_SYNC_TIME] = settings.lastSyncTime
            preferences[MOBILE_SYNC_ENABLED] = settings.mobileSyncEnabled
        }
    }
    
    suspend fun addSyncLog(entry: SyncLogEntry) {
        context.syncDataStore.edit { preferences ->
            val currentJson = preferences[SYNC_LOGS] ?: "[]"
            val type = object : TypeToken<MutableList<SyncLogEntry>>() {}.type
            val logs: MutableList<SyncLogEntry> = try {
                gson.fromJson(currentJson, type) ?: mutableListOf()
            } catch (e: Exception) {
                mutableListOf()
            }
            
            // 添加新日志到开头
            logs.add(0, entry)
            
            // 只保留最近N条
            while (logs.size > MAX_LOG_ENTRIES) {
                logs.removeAt(logs.size - 1)
            }
            
            preferences[SYNC_LOGS] = gson.toJson(logs)
        }
    }
    
    suspend fun clearSyncSettings() {
        context.syncDataStore.edit { preferences ->
            preferences.clear()
        }
    }
    
    suspend fun clearAuth() {
        context.syncDataStore.edit { preferences ->
            preferences[AUTH_TOKEN] = ""
            preferences[USER_ID] = 0
            preferences[USERNAME] = ""
        }
    }
}
