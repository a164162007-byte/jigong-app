package com.worklogger.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.worklogger.app.model.QuickPhrase
import com.worklogger.app.model.WorkRecord

/**
 * Room 数据库
 */
@Database(
    entities = [WorkRecord::class, QuickPhrase::class],
    version = 2,  // 从1升级到2，添加同步字段
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    
    abstract fun workRecordDao(): WorkRecordDao
    abstract fun quickPhraseDao(): QuickPhraseDao
    
    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null
        
        // 迁移策略：从v1迁移到v2，添加同步字段
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // 添加同步状态字段
                database.execSQL(
                    "ALTER TABLE work_records ADD COLUMN syncStatus INTEGER DEFAULT 1 NOT NULL"
                )
                // 添加最后同步时间字段
                database.execSQL(
                    "ALTER TABLE work_records ADD COLUMN lastSyncAt INTEGER DEFAULT 0 NOT NULL"
                )
                // 添加服务器ID字段
                database.execSQL(
                    "ALTER TABLE work_records ADD COLUMN serverId INTEGER"
                )
            }
        }
        
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "work_logger_db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
