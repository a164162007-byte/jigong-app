package com.worklogger.app.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.worklogger.app.model.SyncLogEntry
import com.worklogger.app.model.SyncLogType
import com.worklogger.app.model.SyncSettings
import com.worklogger.app.sync.SyncState
import java.text.SimpleDateFormat
import java.util.*

/**
 * 同步设置区域组件
 * 用于嵌入到设置页面中
 */
@Composable
fun SyncSettingsSection(
    viewModel: SyncSettingsViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val settings = uiState.syncSettings
    
    Column(modifier = modifier) {
        // 云同步开关
        SettingsSection(title = "云同步")
        
        SwitchSettingItem(
            title = "启用云同步",
            subtitle = "同步数据到Web版服务器",
            checked = settings.syncEnabled,
            onCheckedChange = { viewModel.toggleSyncEnabled(it) }
        )
        
        if (settings.syncEnabled) {
            Spacer(modifier = Modifier.height(8.dp))
            
            // 服务器地址
            ClickableSettingItem(
                title = "服务器地址",
                value = settings.serverUrl,
                icon = Icons.Outlined.Cloud,
                onClick = { viewModel.showServerUrlDialog() }
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // 账号状态
            if (settings.authToken.isNotEmpty()) {
                AccountStatusCard(
                    username = settings.username,
                    onLogout = { viewModel.logout() }
                )
            } else {
                SettingItem(
                    title = "账号绑定",
                    subtitle = "未登录",
                    icon = Icons.Outlined.AccountCircle,
                    onClick = { viewModel.showLoginDialog() },
                    isClickable = true
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // 同步状态
            SyncStatusCard(
                isSyncing = uiState.isSyncing,
                lastSyncTime = settings.lastSyncTime,
                pendingCount = settings.pendingCount,
                onSyncClick = { viewModel.triggerManualSync() }
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // 移动网络同步
            SwitchSettingItem(
                title = "移动网络同步",
                subtitle = "允许在非WiFi下自动同步",
                checked = settings.mobileSyncEnabled,
                onCheckedChange = { viewModel.toggleMobileSync(it) }
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // 同步日志
            if (uiState.syncLogs.isNotEmpty()) {
                SyncLogsCard(logs = uiState.syncLogs)
            }
        }
    }
    
    // 登录对话框
    if (uiState.showLoginDialog) {
        LoginDialog(
            isLoading = uiState.isLoggingIn,
            errorMessage = uiState.errorMessage,
            onDismiss = { viewModel.hideLoginDialog() },
            onLogin = { username, password -> viewModel.login(username, password) }
        )
    }
    
    // 服务器地址对话框
    if (uiState.showServerUrlDialog) {
        ServerUrlDialog(
            currentUrl = settings.serverUrl,
            onDismiss = { viewModel.hideServerUrlDialog() },
            onConfirm = { url -> viewModel.updateServerUrl(url) }
        )
    }
}

@Composable
private fun AccountStatusCard(
    username: String,
    onLogout: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Outlined.AccountCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "已登录账号",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = username,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium
                )
            }
            TextButton(onClick = onLogout) {
                Text("退出")
            }
        }
    }
}

@Composable
private fun SyncStatusCard(
    isSyncing: Boolean,
    lastSyncTime: Long,
    pendingCount: Int,
    onSyncClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "同步状态",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (lastSyncTime > 0) {
                        Text(
                            text = "上次同步: ${formatDateTime(lastSyncTime)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text(
                            text = "从未同步",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                
                Button(
                    onClick = onSyncClick,
                    enabled = !isSyncing
                ) {
                    if (isSyncing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("同步中...")
                    } else {
                        Icon(
                            imageVector = Icons.Outlined.Sync,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("立即同步")
                    }
                }
            }
            
            if (pendingCount > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "待同步: $pendingCount 条记录",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }
        }
    }
}

@Composable
private fun SyncLogsCard(logs: List<SyncLogEntry>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "最近同步记录",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            
            logs.take(5).forEach { log ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (log.success) Icons.Outlined.CheckCircle else Icons.Outlined.Error,
                        contentDescription = null,
                        tint = if (log.success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = log.message,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "${getSyncTypeName(log.type)} · ${formatDateTime(log.timestamp)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LoginDialog(
    isLoading: Boolean,
    errorMessage: String?,
    onDismiss: () -> Unit,
    onLogin: (String, String) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.padding(16.dp),
            shape = MaterialTheme.shapes.large
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "登录Web版账号",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("用户名") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    enabled = !isLoading
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("密码") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    enabled = !isLoading
                )
                
                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onDismiss,
                        enabled = !isLoading
                    ) {
                        Text("取消")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onLogin(username, password) },
                        enabled = !isLoading && username.isNotBlank() && password.isNotBlank()
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text("登录")
                    }
                }
            }
        }
    }
}

@Composable
private fun ServerUrlDialog(
    currentUrl: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var url by remember { mutableStateOf(currentUrl) }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.padding(16.dp),
            shape = MaterialTheme.shapes.large
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "设置服务器地址",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("服务器URL") },
                    placeholder = { Text("http://192.168.1.100:8080") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "输入Docker部署的Web版服务器地址",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("取消")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onConfirm(url) },
                        enabled = url.isNotBlank()
                    ) {
                        Text("确认")
                    }
                }
            }
        }
    }
}

private fun formatDateTime(timestamp: Long): String {
    if (timestamp == 0L) return "从未"
    val sdf = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

private fun getSyncTypeName(type: SyncLogType): String {
    return when (type) {
        SyncLogType.UPLOAD -> "上传"
        SyncLogType.DOWNLOAD -> "下载"
        SyncLogType.LOGIN -> "登录"
        SyncLogType.MANUAL -> "手动同步"
        SyncLogType.AUTO -> "自动同步"
    }
}
