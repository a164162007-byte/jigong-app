package com.worklogger.app.data.remote

import retrofit2.Response
import retrofit2.http.*

/**
 * 工作记录API服务接口
 */
interface WorkApiService {
    
    // ==================== 认证接口 ====================
    
    /**
     * 用户登录
     */
    @POST("/api/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>
    
    /**
     * 用户注册
     */
    @POST("/api/register")
    suspend fun register(@Body request: RegisterRequest): Response<BaseResponse>
    
    // ==================== 记录CRUD接口 ====================
    
    /**
     * 获取记录列表
     * @param lastSync 最后同步时间戳，获取此时间之后变更的记录
     */
    @GET("/api/records")
    suspend fun getRecords(
        @Query("last_sync") lastSync: Long = 0
    ): Response<RecordsResponse>
    
    /**
     * 添加记录
     */
    @POST("/api/records")
    suspend fun addRecord(@Body record: ServerWorkRecord): Response<BaseResponse>
    
    /**
     * 更新记录
     */
    @PUT("/api/records/{id}")
    suspend fun updateRecord(
        @Path("id") id: Int,
        @Body record: ServerWorkRecord
    ): Response<BaseResponse>
    
    /**
     * 删除记录
     */
    @DELETE("/api/records/{id}")
    suspend fun deleteRecord(@Path("id") id: Int): Response<BaseResponse>
    
    // ==================== 批量同步接口 ====================
    
    /**
     * 批量同步记录
     * 上传本地变更，同时获取服务器变更
     */
    @POST("/api/records/batch")
    suspend fun batchSync(@Body request: BatchSyncRequest): Response<BatchSyncResponse>
    
    // ==================== 用户接口 ====================
    
    /**
     * 验证Token是否有效
     */
    @GET("/api/user/profile")
    suspend fun getProfile(): Response<LoginResponse>
    
    /**
     * 退出登录
     */
    @POST("/api/logout")
    suspend fun logout(): Response<BaseResponse>
}
