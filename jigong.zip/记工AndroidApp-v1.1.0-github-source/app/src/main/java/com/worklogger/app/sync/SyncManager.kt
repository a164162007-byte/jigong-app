package com.worklogger.app.sync

import android.content.Context
import androidx.work.*
import com.worklogger.app.data.local.SyncSettingsDataStore
import com.worklogger.app.data.remote.*
import com.worklogger.app.model.SyncLogEntry
import com.worklogger.app.model.SyncLogType
import com.worklogger.app.model.SyncSettings
import com.worklogger.app.model.SyncStatus
import com.worklogger.app.model.WorkRecord
import kotlinx.coroutines.flow.*
import java.util.concurrent.TimeUnit

/**
 * 同步管理器
 */
class SyncManager(private val context: Context) {
    
    private val syncSettingsDataStore = SyncSettingsDataStore(context)
    private val networkMonitor = NetworkMonitor(context)
    
    companion object {
        private const val SYNC_WORK_NAME = "work_logger_sync"
        private const val MANUAL_SYNC_WORK_NAME = "work_logger_sync_manual"
        
        // WiFi同步间隔：30分钟
        private const val SYNC_INTERVAL_MINUTES = 30L
        
        // 重试延迟序列：30秒、1分钟、5分钟
        private val RETRY_DELAYS = listOf(30L, 60L, 300L)
    }
    
    val syncSettings: StateFlow<SyncSettings> = syncSettingsDataStore.syncSettings
        .stateIn(
            scope = kotlinx.coroutines.GlobalScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = SyncSettings()
        )
    
    val syncLogs: StateFlow<List<SyncLogEntry>> = syncSettingsDataStore.syncLogs
        .stateIn(
            scope = kotlinx.coroutines.GlobalScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    
    val syncState: StateFlow<SyncState> = MutableStateFlow(SyncState.Idle)
        .also { flow ->
            kotlinx.coroutines.GlobalScope.launch {
                flow.collect { state ->
                    // 可以在这里处理同步状态变化
                }
            }
        }
    
    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncStateFlow: Flow<SyncState> = _syncState.asStateFlow()
    
    /**
     * 检查是否正在同步
     */
    fun isSyncing(): Boolean = _syncState.value == SyncState.Syncing
    
    /**
     * 检查是否可以进行同步
     */
    fun canSync(): Boolean {
        val settings = syncSettings.value
        if (!settings.syncEnabled) return false
        if (settings.authToken.isEmpty()) return false
        return networkMonitor.canSync(settings.mobileSyncEnabled)
    }
    
    /**
     * 启动自动同步调度
     */
    fun scheduleAutoSync() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        
        val syncRequest = PeriodicWorkRequestBuilder<SyncWorker>(
            SYNC_INTERVAL_MINUTES, TimeUnit.MINUTES
        )
            .setConstraints(constraints)
            .setBackoffCriteria(
                BackoffPolicy.EXPONENTIAL,
                WorkRequest.MIN_BACKOFF_MILLIS,
                TimeUnit.MILLISECONDS
            )
            .build()
        
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(
                SYNC_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                syncRequest
            )
    }
    
    /**
     * 停止自动同步调度
     */
    fun cancelAutoSync() {
        WorkManager.getInstance(context).cancelUniqueWork(SYNC_WORK_NAME)
    }
    
    /**
     * 触发手动同步
     */
    fun triggerManualSync(): Operation {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        
        val syncRequest = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(constraints)
            .build()
        
        return WorkManager.getInstance(context)
            .enqueueUniqueWork(
                MANUAL_SYNC_WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                syncRequest
            )
    }
    
    /**
     * 更新同步设置
     */
    suspend fun updateSyncEnabled(enabled: Boolean) {
        syncSettingsDataStore.updateSyncEnabled(enabled)
        if (enabled) {
            scheduleAutoSync()
        } else {
            cancelAutoSync()
        }
    }
    
    suspend fun updateServerUrl(url: String) {
        syncSettingsDataStore.updateServerUrl(url)
        RetrofitClient.updateBaseUrl(url)
    }
    
    suspend fun updateMobileSyncEnabled(enabled: Boolean) {
        syncSettingsDataStore.updateMobileSyncEnabled(enabled)
    }
    
    /**
     * 登录
     */
    suspend fun login(username: String, password: String): Result<LoginResponse> {
        return try {
            RetrofitClient.updateBaseUrl(syncSettings.value.serverUrl)
            val response = RetrofitClient.getService().login(LoginRequest(username, password))
            
            if (response.isSuccessful && response.body()?.success == true) {
                val loginResponse = response.body()!!
                val token = loginResponse.token ?: ""
                val userId = loginResponse.userId ?: 0
                
                // 保存认证信息
                syncSettingsDataStore.updateAuthToken(token)
                syncSettingsDataStore.updateUserId(userId)
                syncSettingsDataStore.updateUsername(username)
                RetrofitClient.updateToken(token)
                
                // 添加登录日志
                syncSettingsDataStore.addSyncLog(
                    SyncLogEntry(
                        type = SyncLogType.LOGIN,
                        message = "登录成功: $username",
                        success = true
                    )
                )
                
                Result.success(loginResponse)
            } else {
                val message = response.body()?.message ?: "登录失败"
                syncSettingsDataStore.addSyncLog(
                    SyncLogEntry(
                        type = SyncLogType.LOGIN,
                        message = "登录失败: $message",
                        success = false
                    )
                )
                Result.failure(Exception(message))
            }
        } catch (e: Exception) {
            syncSettingsDataStore.addSyncLog(
                SyncLogEntry(
                    type = SyncLogType.LOGIN,
                    message = "登录异常: ${e.message}",
                    success = false
                )
            )
            Result.failure(e)
        }
    }
    
    /**
     * 登出
     */
    suspend fun logout() {
        try {
            RetrofitClient.getService().logout()
        } catch (e: Exception) {
            // 忽略退出登录API错误
        }
        
        RetrofitClient.updateToken(null)
        syncSettingsDataStore.clearAuth()
        cancelAutoSync()
    }
    
    /**
     * 更新同步状态
     */
    fun updateSyncState(state: SyncState) {
        _syncState.value = state
    }
    
    /**
     * 更新最后同步时间
     */
    suspend fun updateLastSyncTime(time: Long) {
        syncSettingsDataStore.updateLastSyncTime(time)
    }
    
    /**
     * 添加同步日志
     */
    suspend fun addSyncLog(entry: SyncLogEntry) {
        syncSettingsDataStore.addSyncLog(entry)
    }
    
    /**
     * 初始化同步管理器
     */
    suspend fun initialize() {
        // 从存储恢复设置
        val settings = syncSettings.first()
        if (settings.syncEnabled && settings.authToken.isNotEmpty()) {
            RetrofitClient.updateBaseUrl(settings.serverUrl)
            RetrofitClient.updateToken(settings.authToken)
            scheduleAutoSync()
        }
    }
}

/**
 * 同步状态
 */
sealed class SyncState {
    object Idle : SyncState()
    object Syncing : SyncState()
    data class Success(val message: String) : SyncState()
    data class Error(val message: String) : SyncState()
}
