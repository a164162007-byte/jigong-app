package com.worklogger.app

import android.app.Application
import com.worklogger.app.data.local.AppDatabase
import com.worklogger.app.data.local.SettingsDataStore
import com.worklogger.app.data.local.SyncSettingsDataStore
import com.worklogger.app.data.repository.SettingsRepository
import com.worklogger.app.data.repository.WorkRepository
import com.worklogger.app.sync.SyncManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Application 类
 */
class WorkLoggerApp : Application() {
    
    lateinit var database: AppDatabase
        private set
    
    lateinit var workRepository: WorkRepository
        private set
    
    lateinit var settingsRepository: SettingsRepository
        private set
    
    lateinit var syncSettingsDataStore: SyncSettingsDataStore
        private set
    
    override fun onCreate() {
        super.onCreate()
        instance = this
        
        // 初始化数据库
        database = AppDatabase.getInstance(this)
        
        // 初始化仓库
        workRepository = WorkRepository(
            database.workRecordDao(),
            database.quickPhraseDao()
        )
        
        settingsRepository = SettingsRepository(SettingsDataStore(this))
        
        // 初始化同步设置存储
        syncSettingsDataStore = SyncSettingsDataStore(this)
        
        // 初始化同步管理器
        val syncManager = SyncManager(this)
        CoroutineScope(Dispatchers.IO).launch {
            syncManager.initialize()
        }
    }
    
    companion object {
        lateinit var instance: WorkLoggerApp
            private set
    }
}
